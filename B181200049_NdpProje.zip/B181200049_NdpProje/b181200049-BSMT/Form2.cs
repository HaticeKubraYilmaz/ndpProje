﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace b181200049_BSMT
{
    public partial class Form2 : Form
    {
      
        public Form2()
        {
            InitializeComponent();
        }
        int indx = -1; //  dataGridView son duracağımız satır indeksi  
       // public int sayac = 0;

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e) // Ekleme düğmesi 
        {

            // Eğer bilgi alanları boş ise:
            if (textBox1.Text.Trim() != "" && textBox2.Text.Trim() != "" && textBox3.Text.Trim() != "" && textBox4.Text.Trim() != "" 
                && textBox5.Text.Trim() != "" && textBox6.Text.Trim() != "")
            {
               
                dataGridView1.Rows.Add(1); // Bir satır ekle
                int toplam = dataGridView1.Rows.Count; // İlk satıra yerleştirmek için sayaç
                // textboxlardan hanelere :
                dataGridView1.Rows[toplam - 2].Cells[0].Value = textBox1.Text;
                dataGridView1.Rows[toplam - 2].Cells[1].Value = textBox2.Text;
                dataGridView1.Rows[toplam - 2].Cells[2].Value = textBox3.Text;
                dataGridView1.Rows[toplam - 2].Cells[3].Value = textBox5.Text;
                dataGridView1.Rows[toplam - 2].Cells[4].Value = textBox4.Text;
                dataGridView1.Rows[toplam - 2].Cells[5].Value = textBox6.Text;

                // textboxları tekrar boşaltmak için 
                textBox1.Text = " ";
                textBox2.Text = " ";
                textBox3.Text = " ";
                textBox4.Text = " ";
                textBox5.Text = " ";
                textBox6.Text = " ";
                textBox1.Focus();
                
            }
            // En az bir alan boşsa
            else MessageBox.Show("TÜM ALANLARI DOLDURUNUZ..");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) // Silme düğmesi 
        {
            if (dataGridView1.CurrentRow.Cells[0].Value != null) // dataGridView boş değilse:
                dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index); // Seçilen satır  
            else MessageBox.Show("LÜTFEN BİR KAYIT SEÇİNİZ.."); // Herhangi bir satır seçilmemişse 
        }

        private void button3_Click(object sender, EventArgs e) // Seçme düğesi
        {
            if (dataGridView1.CurrentRow.Cells[0].Value != null) // Tablo boş değilse
            {
                // Seçilen satırın değerlerini gerekli alanlara aktarmak için 
                textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                textBox4.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                textBox5.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                textBox6.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
                
                indx = dataGridView1.CurrentRow.Index;
            }
            else MessageBox.Show("LÜTFEN BİR KAYIT SEÇİNİZ..");

        }

        private void button4_Click(object sender, EventArgs e) // Güncelleme
        {
            if (indx != -1)
            {
                if (textBox1.Text.Trim() != "" && textBox2.Text.Trim() != "" && textBox3.Text.Trim() != "" && textBox4.Text.Trim() != ""
                    && textBox5.Text.Trim() != "" && textBox6.Text.Trim() != "")
                {
                    dataGridView1.Rows[indx].Cells[0].Value = textBox1.Text;
                    dataGridView1.Rows[indx].Cells[1].Value = textBox2.Text;
                    dataGridView1.Rows[indx].Cells[2].Value = textBox3.Text;
                    dataGridView1.Rows[indx].Cells[4].Value = textBox4.Text;
                    dataGridView1.Rows[indx].Cells[3].Value = textBox5.Text;
                    dataGridView1.Rows[indx].Cells[5].Value = textBox6.Text;
                    
                }
                else MessageBox.Show("TÜM ALANLARI DOLDURUNUZ..");
            }
            else MessageBox.Show("BİR KAYIT SEÇİN.");
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) // Bu alan sadece sayı değerleri alabilir 
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) // Bu alan sadece sayı değerleri alabilir 
            {
                e.Handled = true;
            }
        }
    }
    }

       
  