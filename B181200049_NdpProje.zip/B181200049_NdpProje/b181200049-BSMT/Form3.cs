﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace b181200049_BSMT
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        // Alanlardan listbox a gönderİlecek bilgilerin değişkenleri 
        int i = 1;
        string[] konu = new string[15];
        string[] konusmaci = new string[15];
        string[] tarih = new string[15];
        string[] saat = new string[15];
        string[] tur = new string[15];



        private void Form3_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add(""); // listboxta ilk satırı boş bırakmak için 
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // eğer konuşmacı varsa "KONUŞMACI" alanını göstermek için
            if (comboBox1.SelectedIndex == 0) // var seçeneğinin indeksi 
            {
                label3.Visible = true;
                textBox2.Visible = true;
            }
            else // yok ise
            {
                label3.Visible = false;
                textBox2.Visible = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e) // ekle
        {
            if (i < 10000)
            {
                konu[i] = textBox1.Text;
                if (textBox2.Text == "") konusmaci[i] = "YOK"; // konuşmacı alanı boşsa
                else konusmaci[i] = textBox2.Text;
                tarih[i] = dateTimePicker1.Text;
                saat[i] = textBox3.Text;
                if (radioButton1.Checked) tur[i] = radioButton1.Text;
                else if (radioButton2.Checked) tur[i] = radioButton2.Text;
                else if (radioButton3.Checked) tur[i] = radioButton3.Text;
                else if (radioButton4.Checked) tur[i] = radioButton4.Text;
                else if (radioButton5.Checked) tur[i] = radioButton5.Text;
                else  tur[i] = radioButton6.Text; // hiçbir şey seçilmemişse DİĞER yazdırmak 



                
                listBox1.Items.Add(konu[i] + "\t" + konusmaci[i] + "\t" + tarih[i] + "\t" + saat[i] + "\t" + tur[i] );
                i++;
            }

            MessageBox.Show("kayit eklendi");
            // alanları boşaltmak
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            dateTimePicker1.ResetText();
      
        }

       

       

       

        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
           // tur[i]
          /*  label1.Text    = radioButton1.Checked ? "Konferans" : radioButton2.Checked ? "Eğitim"
                   : radioButton3.Checked ? "Eğitim Kamğı" : radioButton4.Checked ? "Toplumsal Duyarlılık"
                   : (radioButton5.Checked ? "Teknik Gezi" : "Diğer");*/
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //  try   - catch * listten bir satır silmek
            try
            {
                listBox1.Items.Remove(listBox1.SelectedItem);
                MessageBox.Show("Veri Silindi.");
            }
            catch (Exception)
            {
                MessageBox.Show("Veri Seçilmemiş.");
            }
        }

        private void button3_Click(object sender, EventArgs e) // arama
        {
            listBox1.SelectedItems.Clear(); 
            for (int i = listBox1.Items.Count - 1; i >=0 ; i--) // haneler indeksi 
            {
               
                if (listBox1.Items[i].ToString().ToLower().Contains(textBox4.Text.ToLower())) // textboxta yazılan kelime listboxla karşılaştırılıyor
                    
                {
                    listBox1.SetSelected(i, true);
                }
            }
            label7.Text = listBox1.SelectedItems.Count.ToString() /* sonuç sayısı */ + " Sonuç bulundu ";     
                }

        private void button4_Click(object sender, EventArgs e) // Kayıt et
        {
            SaveFileDialog dlg = new SaveFileDialog();
            if ( dlg.ShowDialog() == DialogResult.OK)
            {
                StreamWriter writer = new StreamWriter(dlg.FileName);

                for (i=0; i < listBox1.Items.Count; i++)
                {
                    writer.WriteLine((string)listBox1.Items[i]);
                }
                writer.Close();

             }
            dlg.Dispose();
        }
    }
}
