﻿/**************************
** SAKARYA ÜNİVERSİTESİ
** BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
** BİLİŞİM SİSTEMLERİ MÜHENDİSLİĞİ BÖLÜMÜ
** NESNEYE DAYALI PROGRAMLAMA DERSİ
** 2019-2020 BAHAR DÖNEMİ
**
** PROJE NUMARASI.........: 01
** ÖĞRENCİ ADI............: Hatice Kübra YILMAZ
** ÖĞRENCİ NUMARASI.......: B181200049
** DERSİN ALINDIĞI GRUP...: A
**************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace b181200049_BSMT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();   // Yeni form - Üye formu
            form2.Show(); 
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Kapatma düğmesi 
            //System.Windows.Forms.Application.ExitThread();
            DialogResult dig = MessageBox.Show("Çıkmak istediğinize emin misiniz", "ÇIKIŞ", MessageBoxButtons.YesNo); /* 2 seçenekli yeni bir diyalog 
            aç */
            switch (dig)     // ****** SWITCH CASE *** /// 
            {
                case DialogResult.Yes:
                    Application.Exit();
                    break;
                case DialogResult.No:
                    //Hiç bir şey yapma :) 
                 break;

            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Fare ile düğmenin üstüne gelindiğinde çıkan açıklama
            System.Windows.Forms.ToolTip ToolTip1 = new System.Windows.Forms.ToolTip();
            ToolTip1.SetToolTip(this.button1, " Üye İşlemleri ");
            System.Windows.Forms.ToolTip ToolTip2 = new System.Windows.Forms.ToolTip();
            ToolTip2.SetToolTip(this.button2, " Etkinlik İşlemleri ");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Yeni form - Etkinlik formu 
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void button1_KeyUp(object sender, KeyEventArgs e)
        {
    
        }

        private void button1_MouseUp(object sender, MouseEventArgs e)
        {

        }
    }
}
